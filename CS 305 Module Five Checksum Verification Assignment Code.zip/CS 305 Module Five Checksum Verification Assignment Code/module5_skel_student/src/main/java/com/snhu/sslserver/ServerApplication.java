package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.math.BigInteger; 
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class ServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }
}

@RestController
class ServerController {

    // Method to calculate hash using SHA-256
    public static String calculateHash(String name) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(name.getBytes(StandardCharsets.UTF_8));
            BigInteger number = new BigInteger(1, hash);
            StringBuilder hexString = new StringBuilder(number.toString(16));
            while (hexString.length() < 64) { // Ensure the hash has 64 characters (SHA-256 standard)
                hexString.insert(0, '0');
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            return "Error: Unable to compute hash";
        }
    }

    // RESTful endpoint to generate and return hash
    @RequestMapping("/hash")
    public String myHash() {
        String data = "Hello Abdulrahman Al-Nachar!";
        String hash = calculateHash(data);

        // Return the data and the hash value
        return "<p>Data: " + data + "</p>" +
               "<p>Algorithm: SHA-256</p>" +
               "<p>Checksum: " + hash + "</p>";
    }
}
