package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class ServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }
}

@RestController
class ServerController {

    // checksum method
    public static String calculateHash(String data) {
        try {

            MessageDigest md = MessageDigest.getInstance("SHA-256");

    
            byte[] hashBytes = md.digest(data.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                hexString.append(String.format("%02x", b));
            }

            return hexString.toString();
        } catch (Exception e) {
            return "Error calculating hash";
        }
    }

    @RequestMapping("/hash")
    public String myHash() {

        String data = "Abdulrahman Al-Nachar"; 
        String algorithm = "SHA-256"; 
        String hash = calculateHash(data);
        return "<p>Data: This is Your First & Last Name " + data + "</p>" +
               "<p>Name of Cipher Algorithm Used: " + algorithm +
               " CheckSum Value: " + hash + "</p>";
    }
}
